package com.example.spring.boot.project.with.db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProjectWithDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
