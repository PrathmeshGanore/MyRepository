package com.example.spring.boot.project.with.db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootProjectWithDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProjectWithDbApplication.class, args);
		System.out.println("Spring is Running");
	}

}
