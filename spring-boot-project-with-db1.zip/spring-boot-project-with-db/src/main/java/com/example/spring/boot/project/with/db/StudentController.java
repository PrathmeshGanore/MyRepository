package com.example.spring.boot.project.with.db;


import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class StudentController {


	@Autowired
	SessionFactory sf;
	
	@RequestMapping("single")
	public Student singleRecord() {
		Session ss = sf.openSession();
		Student s = ss.get(Student.class, 101);
		return s;
	}
	
	@RequestMapping("All")
	public Student AllRecord() {
		Session ss = sf.openSession();
		Student student=new Student();
		Query query=ss.createQuery("from student");
		List<Student> list=query.list();
		for (Student student1 : list) {
		student1.getId();
		student1.getName();
		}
		
		return student;
	}
	
	
	
	@RequestMapping("insert")
	public Student insert() {
		
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();


		Student s = new Student(103, "Prathmesh");


		ss.save(s);


		System.out.println(s);


		tx.commit();
		
		return s;


	}
	
	@RequestMapping("update")
	public Student update() {
		
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();


		Student s = new Student(103, "Sagar");


		ss.update(s);


		System.out.println(s);


		tx.commit();
		
		return s;


	}
	
	// Non Parameter
	// parameter -> @PathVariable/@RequestBody
	
	@RequestMapping("delete")
	public Student delete() {
		
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();


		Student s = new Student(103, "Sagar");


		ss.delete(s);


		System.out.println(s);


		tx.commit();
		
		return s;


	}
	
}